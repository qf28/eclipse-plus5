package org.eclipse.birt.report.engine.api.script.instance;

public interface IScriptStyle {

	String getVisibility();

	void setVisibility(String visibility);

	/**
	 * Get the letter spacing
	 */
	String getLetterSpacing();

	/**
	 * Set the letter spacing
	 */
	void setLetterSpacing(String spacing);

	/**
	 * Get the line height
	 */
	String getLineHeight();

	/**
	 * Set the line height
	 */
	void setLineHeight(String lineHeight);

	/**
	 * Get the text alignment. Valid return types are LEFT, RIGHT, CENTER and
	 * JUSTIFY.
	 */
	String getTextAlign();

	/**
	 * Set the text alignment. Valid return types are LEFT, RIGHT, CENTER and
	 * JUSTIFY.
	 */
	void setAlign(String align);

	/**
	 * Get the text indent
	 */
	String getTextIndent();

	/**
	 * Get the text indent
	 */
	void setTextIndent(String indent);

	/**
	 * Get the text transform. Valid return values are NONE, CAPITALIZE,
	 * UPPERCASE and LOWERCASE.
	 */
	String getTransform();

	/**
	 * Set the text transform. Valid transform values are NONE, CAPITALIZE,
	 * UPPERCASE and LOWERCASE.
	 */
	void setTextTransform(String transform);

	/**
	 * Get the vertical alignment. Valid return values are BASELINE, SUB, SUPER,
	 * TOP, TEXT_TOP, MIDDLE, BOTTOM and TEXT_BOTTOM
	 */
	String getVerticalAlign();

	/**
	 * Set the vertical alignment. Valid values are BASELINE, SUB, SUPER, TOP,
	 * TEXT_TOP, MIDDLE, BOTTOM and TEXT_BOTTOM
	 */
	void setVerticalAlign(String valign);

	/**
	 * Get the whitespace. Valid return values are NORMAL, PRE and NOWRAP
	 */
	String getWhiteSpace();

	/**
	 * Get the whitespace. Valid return values are NORMAL, PRE and NOWRAP
	 */
	void setWhiteSpace(String whitespace);

	/**
	 * Get the word spacing
	 */
	String getWordSpacing();

	/**
	 * Set the word spacing
	 */
	void setWordSpacing(String wordspacing);

	/**
	 * Get the font color
	 */
	String getColor();

	/**
	 * Set the font color
	 */
	void setColor(String color);

	/**
	 * Get the attachement type (either SCROLL or FIXED)
	 */
	String getBackgroundAttachement();

	/**
	 * Set the attachement type (either SCROLL or FIXED)
	 */
	void setBackgroundAttachement(String attachement);

	/**
	 * Get the background color
	 */
	String getBackgroundColor();

	/**
	 * Set the background color
	 */
	void setBackgroundColor(String color);

	/**
	 * Get the background image URI
	 */
	String getBackgroundImage();

	/**
	 * Set the background image URI
	 */
	void setBackgroundImage(String imageURI);

	/**
	 * Get the background repeat type (valid types are REPEAT, REPEAT_X,
	 * REPEAT_Y and NO_REPEAT)
	 */
	String getRepeat();

	/**
	 * Set the background repeat type (valid types are REPEAT, REPEAT_X,
	 * REPEAT_Y and NO_REPEAT)
	 */
	void setRepeat(String repeat);

	/**
	 * Get the bottom border color
	 */
	String getBorderBottomColor();

	/**
	 * Set the bottom border color
	 */
	void setBorderBottomColor(String color);

	/**
	 * Get the top border color
	 */
	String getBorderTopColor();

	/**
	 * Set the top border color
	 */
	void setBorderTopColor(String color);

	/**
	 * Get the right border color
	 */
	String getBorderRightColor();

	/**
	 * Set the right border color
	 */
	void setBorderRightColor(String color);

	/**
	 * Get the left border color
	 */
	String getBorderLeftColor();

	/**
	 * Set the left border color
	 */
	void setBorderLeftColor(String color);

	/**
	 * Get the bottom border style. Valid styles are NONE, SOLID, DOTTED,
	 * DASHED, DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	String getBorderBottomStyle();

	/**
	 * Set the bottom border style. Valid styles are NONE, SOLID, DOTTED,
	 * DASHED, DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	void setBorderBottomStyle(String borderstyle);

	/**
	 * Get the top border style. Valid styles are NONE, SOLID, DOTTED, DASHED,
	 * DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	String getBorderTopStyle();

	/**
	 * Set the top border style. Valid styles are NONE, SOLID, DOTTED, DASHED,
	 * DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	void setBorderTopStyle(String borderstyle);

	/**
	 * Get the left border style. Valid styles are NONE, SOLID, DOTTED, DASHED,
	 * DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	String getBorderLeftStyle();

	/**
	 * Set the left border style. Valid styles are NONE, SOLID, DOTTED, DASHED,
	 * DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	void setBorderLeftStyle(String borderstyle);

	/**
	 * Get the right border style. Valid styles are NONE, SOLID, DOTTED, DASHED,
	 * DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	String getBorderRightStyle();

	/**
	 * Set the right border style. Valid styles are NONE, SOLID, DOTTED, DASHED,
	 * DOUBLE, GROVE, RIDGE, INSET and OUTSET.
	 */
	void setBorderRightStyle(String borderstyle);

	/**
	 * Get the bottom border width.
	 */
	String getBorderBottomWidth();

	/**
	 * Set the bottom border width.
	 */
	void setBorderBottomWidth(String width);

	/**
	 * Get the top border width.
	 */
	String getBorderTopWidth();

	/**
	 * Set the top border width.
	 */
	void setBorderTopWidth(String width);

	/**
	 * Get the left border width.
	 */
	String getBorderLeftWidth();

	/**
	 * Set the left border width.
	 */
	void setBorderLeftWidth(String width);

	/**
	 * Get the right border width.
	 */
	String getBorderRightWidth();

	/**
	 * Set the right border width.
	 */
	void setBorderRightWidth(String width);

	/**
	 * Get the bottom margin
	 */
	String getMarginBottom();

	/**
	 * Set the bottom margin
	 */
	void setMarginBottom(String margin);

	/**
	 * Get the top margin
	 */
	String getMarginTop();

	/**
	 * Set the top margin
	 */
	void setMarginTop(String margin);

	/**
	 * Get the left margin
	 */
	String getMarginLeft();

	/**
	 * Set the left margin
	 */
	void setMarginLeft(String margin);

	/**
	 * Get the right margin
	 */
	String getMarginRight();

	/**
	 * Set the right margin
	 */
	void setMarginRight(String margin);

	/**
	 * Get the bottom padding.
	 */
	String getPaddingBottom();

	/**
	 * Set the bottom padding.
	 */
	void setPaddingBottom(String padding);

	/**
	 * Get the top padding.
	 */
	String getPaddingTop();

	/**
	 * Set the top padding.
	 */
	void setPaddingTop(String padding);

	/**
	 * Get the left padding.
	 */
	String getPaddingLeft();

	/**
	 * Set the left padding.
	 */
	void setPaddingLeft(String padding);

	/**
	 * Get the right padding.
	 */
	String getPaddingRight();

	/**
	 * Set the right padding.
	 */
	void setPaddingRight(String padding);

	/**
	 * Get the display type (valid types are BLOCK, INLINE and NONE)
	 */
	String getDisplay();

	/**
	 * Set the display type (valid types are BLOCK, INLINE and NONE)
	 */
	void setDisplay(String display);

	/**
	 * Get the master page
	 */
	String getMasterPage();

	/**
	 * Set the master page
	 */
	void setMasterPage(String masterPage);

	/**
	 * Get the page break before.
	 */
	String getPageBreakBefore();

	/**
	 * Set the page break before
	 */
	void setPageBreakBefore(String pageBreak);

	/**
	 * Get the page break after.
	 */
	String getPageBreakAfter();

	/**
	 * Set the page break after
	 */
	void setPageBreakAfter(String pageBreak);

	/**
	 * Get the page break inside.
	 */
	String getPageBreakInside();

	/**
	 * Set the page break inside
	 */
	void setPageBreakInside(String pageBreak);

	/**
	 * Show if blank?
	 */
	String getShowIfBlank();

	/**
	 * Set show if blank
	 */
	void setShowIfBlank(String showIfBlank);

	/**
	 * Can this element shrink?
	 */
	String getCanShrink();

	/**
	 * Can this element shrink?
	 */
	void setCanShrink(String canShrink);

	/**
	 * Get number format
	 * 
	 * @return the number format
	 */
	String getNumberFormat();

	/**
	 * Set the number format
	 * 
	 * @param numberFormat
	 */
	void setNumberFormat(String numberFormat);

	/**
	 * Get the date format
	 * 
	 * @return date format
	 */
	String getDateFormat();

	/**
	 * Set the date format
	 * 
	 * @param dateTimeFormat
	 */
	void setDateFormat(String dateTimeFormat);

	/**
	 * Get the string format
	 * 
	 * @return the string format
	 */
	String getStringFormat();

	/**
	 * Set the string format
	 * 
	 * @param stringFormat
	 */
	void setStringFormat(String stringFormat);

}